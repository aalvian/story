export default class AddPage {
  async render() {
    return `
        <section class="container">
          <h1>Add Page</h1>
        </section>
      `;
  }

  async afterRender() {
    // Do your job here
  }
}
